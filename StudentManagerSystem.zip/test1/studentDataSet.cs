﻿namespace test1
{


    partial class studentDataSet
    {
    }
}
